@echo off
title VMX.exe
mode con: cols=80 lines=25
color 0a
setlocal enabledelayedexpansion

:startup
cls
echo ==========================================
echo            VMX.exe INITIALIZING
echo ==========================================
echo.
echo Scanning weird files...
timeout /t 2 >nul

:: Fake loading bar
cls
echo Loading...
set bar=

for /L %%i in (1,1,30) do (
    set bar=!bar!#
    cls
    echo Loading VMX.exe...
    echo.
    echo [!bar!]
    timeout /t 1 >nul
)

:: Random weird messages
:weird
cls
color 0c
echo WARNING: SIGNAL DETECTED...
timeout /t 1 >nul

color 09
echo ?? UNKNOWN CONNECTION ??
timeout /t 1 >nul

color 0e
echo ERROR: FILE reality.exe NOT FOUND
timeout /t 2 >nul

color 0d
echo Detecting potatoes...
timeout /t 1 >nul

echo SUCCESS: 942 potatoes detected.
timeout /t 2 >nul

:: Fake glitch spam
cls
for /L %%i in (1,1,15) do (
    color %%i
    echo A#$e&*#gy*gf yOu#&*ehhrN
    echo #### SYSTEM GLITCH ####
    echo %%random%% %%random%% %%random%%
    ping localhost -n 2 >nul
)

:: Beep sound (system bell)
echo ^G
echo ^G
echo ^G

:: Fake shutdown scare
cls
color 4f
echo WARNING!!!
echo.
echo VMX.exe has taken over...
echo.
timeout /t 3 >nul

cls
echo.
echo.
echo VMX.EXE
echo.
echo #**(#*#&e4
timeout /t 4 >nul

:: ===============================
:: Stage: Ransomware Demonstration 
:: ===============================
cls
color 4f
echo WARNING!!!
echo.
echo VMX.exe Has Locked Your PC.
echo.
echo In 10 Seconds If No 1 BTC Was Paid...
echo Guess What Happens Next...
echo.
echo VMX.exe Will Show You.
timeout /t 10 >nul

cls
color 0c
echo You Did Not Listen.
echo.
echo Now See Real Damage. HAHAHAAHAA
timeout /t 3 >nul

:: Desktop location
set "desktop=%USERPROFILE%\Desktop"

:: Create 20 harmless text files
for /L %%i in (1,1,20) do (
    (
    echo VMX.exe Will Not Be Removed. EVER
    echo You Didn't Listen And This Is Your Punishment
    ) > "%desktop%\vmxcannotberemoved%%i.txt"
)

:: Create README
(
echo 10 Seconds Was Up.
echo.
echo Q: What Happened?
echo A: Your PC Was Hit By The VMX.exe Virus And Could Not Be Removed.
echo A: 20 New Files Appeared For Not Listening.
echo A: And Now You Had To Suffer The Consequences For Not Doing As What Was Said.
echo.
echo Q: How Can I Recover My Files?
echo A: Dude, This Is Not a Ransomware. You're Fine.
echo A: Just Remove The Text Files And You're Fine. Simple As That.
echo.
echo Q: Where Did The Text Files Get Created?
echo A: In Your Desktop Area.
echo.
echo Q: Is This a Real Virus?
echo A: No. This Was Created By ThatOneModderThatGetsPermaBanned On Github
echo A: To Show What Real Viruses And Ransomwares Can Do To Your PC.
echo A: This Is Just A Reminder To Be Careful What Files You Download.
) > "%desktop%\VMXReadME.txt"

cls
color 0a
echo.
echo VMX prank completed.
echo.
echo Check your desktop 😭
timeout /t 5 >nul

exit