This Is a Custom Virus. It Was Made By Me (ThatOneModderThatGetsPermaBanned) On GitHub.

This Works On XP Or Windows Me - Windows 11

If You Want To Do This Not On Your Real PC, I'd Strongly Recommend You Run This On a VM If You Are Scared Of Getting a Virus On Your Real PC. Saying That To The One Person That Is My Friend Saying Goodbye, While Bro Is Upset Thinking He Got a Virus (No Not Trying To Be Rude To Him)