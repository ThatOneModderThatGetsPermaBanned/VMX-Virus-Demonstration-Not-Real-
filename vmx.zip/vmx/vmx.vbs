' Vmx.vbs

Dim firstChoice, secondChoice
Dim shell

Set shell = CreateObject("WScript.Shell")

' First popup
firstChoice = MsgBox( _
    "Do You Want To Run VMX.exe As This Is Noted Dangerous Files And Can Spread Rapidly. If You Hit No Nothing Will Happen", _
    vbYesNo + vbQuestion, _
    "VM_X.exe")

' If user clicks No, close
If firstChoice = vbNo Then
    WScript.Quit
End If

' Second popup
secondChoice = MsgBox( _
    "A#$e&*#gy*gf yOu#&*ehhrN #SURE?", _
    vbYesNo + vbExclamation, _
    "##&^&#&&#((")

' If user clicks No, close
If secondChoice = vbNo Then
    WScript.Quit
End If

' Run vmx.bat if user clicked Yes
shell.Run "vmx.bat"